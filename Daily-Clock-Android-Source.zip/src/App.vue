<script setup lang="ts">
import { computed, onMounted, ref, watch } from 'vue'
import * as echarts from 'echarts'
import { db, todayKey, money, type Attendance, type Reimbursement } from './db'
import {
  House, CalendarDays, ReceiptText, ChartNoAxesCombined, Settings, Clock3,
  ArrowDownToLine, ArrowUpFromLine, Plus, Check, Sun, Moon, Wallet, BriefcaseBusiness,
  Trash2, Pencil, Download, Upload, Database, ChevronLeft, ChevronRight
} from 'lucide-vue-next'
import * as XLSX from 'xlsx'

type Tab = 'home' | 'records' | 'expense' | 'stats' | 'settings'
const tab = ref<Tab>('home')
const theme = ref<'dark'|'light'>('dark')
const today = todayKey()
const now = ref(new Date())
const attendance = ref<Attendance[]>([])
const reimbursements = ref<Reimbursement[]>([])
const defaultAmount = ref(200)
const selectedMonth = ref(today.slice(0,7))
const selectedYear = ref(Number(today.slice(0,4)))
const showClockDialog = ref(false)
const showExpenseDialog = ref(false)
const showRecordDialog = ref(false)
const editAttendance = ref<Attendance | null>(null)
const editExpense = ref<Reimbursement | null>(null)
const clockForm = ref({ date: today, clockIn: '09:00', clockOut: '18:00', amount: 200, note: '' })
const expenseForm = ref({ date: today, title: '', category: '交通', amount: 0, status: 'pending' as 'pending'|'paid', note: '' })
const recordForm = ref({ date: today, clockIn: '', clockOut: '', amount: 200, note: '' })
const chartEl = ref<HTMLElement|null>(null)
let chart: echarts.ECharts | undefined

const todayRecord = computed(() => attendance.value.find(x => x.date === today))
const monthRecords = computed(() => attendance.value.filter(x => x.date.startsWith(selectedMonth.value)))
const yearRecords = computed(() => attendance.value.filter(x => x.date.startsWith(String(selectedYear.value))))
const monthExpenses = computed(() => reimbursements.value.filter(x => x.date.startsWith(selectedMonth.value)))
const yearExpenses = computed(() => reimbursements.value.filter(x => x.date.startsWith(String(selectedYear.value))))
const monthIncome = computed(() => monthRecords.value.reduce((s,x)=>s + Number(x.amount||0),0))
const yearIncome = computed(() => yearRecords.value.reduce((s,x)=>s + Number(x.amount||0),0))
const monthHours = computed(() => monthRecords.value.reduce((s,x)=>s + duration(x.clockIn,x.clockOut),0))
const pendingAmount = computed(() => monthExpenses.value.filter(x=>x.status==='pending').reduce((s,x)=>s+x.amount,0))
const paidAmount = computed(() => monthExpenses.value.filter(x=>x.status==='paid').reduce((s,x)=>s+x.amount,0))
const monthDays = computed(() => monthRecords.value.length)
const yearDays = computed(() => yearRecords.value.length)
const clockedIn = computed(() => !!todayRecord.value?.clockIn)
const clockedOut = computed(() => !!todayRecord.value?.clockOut)
const monthLabel = computed(() => selectedMonth.value.replace('-', '年') + '月')
const yearLabel = computed(() => `${selectedYear.value} 年`)
const sortedRecords = computed(() => [...attendance.value].sort((a,b)=>b.date.localeCompare(a.date)))
const sortedExpenses = computed(() => [...reimbursements.value].sort((a,b)=>b.date.localeCompare(a.date)))

function duration(a?:string,b?:string) {
  if (!a || !b) return 0
  const [ah,am]=a.split(':').map(Number), [bh,bm]=b.split(':').map(Number)
  let mins = bh*60+bm-(ah*60+am)
  if (mins<0) mins+=1440
  return mins/60
}
function fmtHours(n:number) { return `${Math.floor(n)}小时${Math.round((n%1)*60)}分` }
function timeNow() { return new Date().toLocaleTimeString('zh-CN',{hour:'2-digit',minute:'2-digit',hour12:false}) }
async function refresh() {
  attendance.value = await db.attendance.toArray()
  reimbursements.value = await db.reimbursements.toArray()
  const saved = await db.settings.get('defaultAmount')
  if (saved) defaultAmount.value = Number(saved.value)
  const savedTheme = await db.settings.get('theme')
  if (savedTheme) theme.value = savedTheme.value as 'dark'|'light'
}
async function clockAction(kind:'in'|'out') {
  const record = todayRecord.value
  if (kind==='in' && record?.clockIn) return
  if (kind==='out' && !record?.clockIn) { alert('请先完成上班打卡'); return }
  const current: Attendance = record || { date: today, amount: defaultAmount.value, createdAt: new Date().toISOString() }
  if (kind==='in') current.clockIn = timeNow()
  else current.clockOut = timeNow()
  await db.attendance.put(current)
  await refresh()
}
function openEditRecord(item?:Attendance) {
  editAttendance.value = item || null
  recordForm.value = item
    ? { date:item.date, clockIn:item.clockIn||'', clockOut:item.clockOut||'', amount:item.amount, note:item.note||'' }
    : { date:today, clockIn:'', clockOut:'', amount:defaultAmount.value, note:'' }
  showRecordDialog.value = true
}
async function saveRecord() {
  const existing = attendance.value.find(x=>x.date===recordForm.value.date)
  await db.attendance.put({
    ...(editAttendance.value?.id ? {id:editAttendance.value.id} : existing?.id ? {id:existing.id} : {}),
    ...recordForm.value, createdAt: editAttendance.value?.createdAt || existing?.createdAt || new Date().toISOString()
  })
  showRecordDialog.value=false
  await refresh()
}
async function deleteRecord(item:Attendance) {
  if (!confirm(`确定删除 ${item.date} 的打卡记录吗？`)) return
  if (item.id) await db.attendance.delete(item.id)
  await refresh()
}
function openExpense(item?:Reimbursement) {
  editExpense.value=item||null
  expenseForm.value=item
    ? {date:item.date,title:item.title,category:item.category,amount:item.amount,status:item.status,note:item.note||''}
    : {date:today,title:'',category:'交通',amount:0,status:'pending',note:''}
  showExpenseDialog.value=true
}
async function saveExpense() {
  await db.reimbursements.put({
    ...(editExpense.value?.id ? {id:editExpense.value.id}:{}),
    ...expenseForm.value, createdAt:editExpense.value?.createdAt||new Date().toISOString()
  })
  showExpenseDialog.value=false
  await refresh()
}
async function deleteExpense(item:Reimbursement) {
  if (!confirm('确定删除这条报销记录吗？')) return
  if(item.id) await db.reimbursements.delete(item.id)
  await refresh()
}
async function saveDefault() {
  await db.settings.put({key:'defaultAmount',value:defaultAmount.value})
}
async function toggleTheme() {
  theme.value=theme.value==='dark'?'light':'dark'
  await db.settings.put({key:'theme',value:theme.value})
}
function exportWorkbook() {
  const wb=XLSX.utils.book_new()
  const a=monthRecords.value.map(x=>({日期:x.date,星期:new Date(x.date+'T00:00:00').toLocaleDateString('zh-CN',{weekday:'short'}),上班时间:x.clockIn||'',下班时间:x.clockOut||'',工作时长:duration(x.clockIn,x.clockOut),打卡金额:x.amount,备注:x.note||''}))
  const e=monthExpenses.value.map(x=>({日期:x.date,项目:x.title,分类:x.category,金额:x.amount,状态:x.status==='paid'?'已报销':'待报销',备注:x.note||''}))
  XLSX.utils.book_append_sheet(wb,XLSX.utils.json_to_sheet(a),'打卡记录')
  XLSX.utils.book_append_sheet(wb,XLSX.utils.json_to_sheet(e),'报销记录')
  XLSX.writeFile(wb,`DailyClock_${selectedMonth.value}.xlsx`)
}
function exportAllJSON() {
  const payload={app:'Daily Clock',version:1,exportedAt:new Date().toISOString(),attendance:attendance.value,reimbursements:reimbursements.value,settings:{defaultAmount:defaultAmount.value,theme:theme.value}}
  const blob=new Blob([JSON.stringify(payload,null,2)],{type:'application/json'})
  downloadBlob(blob,`DailyClock_backup_${today}.json`)
}
function downloadBlob(blob:Blob,name:string) {
  const url=URL.createObjectURL(blob), a=document.createElement('a')
  a.href=url;a.download=name;a.click();URL.revokeObjectURL(url)
}
function importFile(event:Event) {
  const input=event.target as HTMLInputElement
  const file=input.files?.[0]
  if(!file)return
  const reader=new FileReader()
  reader.onload=async()=>{
    try {
      const data=reader.result as string
      if(file.name.toLowerCase().endsWith('.json')) {
        const parsed=JSON.parse(data)
        if(!Array.isArray(parsed.attendance)||!Array.isArray(parsed.reimbursements)) throw new Error('JSON 结构不正确')
        const mode=confirm('点击“确定”合并数据；点击“取消”将清空现有打卡和报销记录后导入。')
        await db.transaction('rw',db.attendance,db.reimbursements,async()=>{
          if(!mode){await db.attendance.clear();await db.reimbursements.clear()}
          for(const x of parsed.attendance){const {id,...rest}=x; await db.attendance.put(rest)}
          for(const x of parsed.reimbursements){const {id,...rest}=x; await db.reimbursements.put(rest)}
        })
        if(parsed.settings?.defaultAmount!==undefined){defaultAmount.value=Number(parsed.settings.defaultAmount);await saveDefault()}
        alert('JSON 数据导入成功')
      } else {
        const wb=XLSX.read(data,{type:'binary'})
        const sheet=wb.Sheets[wb.SheetNames[0]]
        const rows=XLSX.utils.sheet_to_json<Record<string,unknown>>(sheet)
        const mapped=rows.map(r=>({
          date:String(r['日期']||r['date']||'').replaceAll('/','-').slice(0,10),
          clockIn:String(r['上班时间']||r['clockIn']||''),
          clockOut:String(r['下班时间']||r['clockOut']||''),
          amount:Number(r['打卡金额']??r['金额']??r['amount']??0),
          note:String(r['备注']||r['note']||''),
          createdAt:new Date().toISOString()
        })).filter(x=>/^\d{4}-\d{2}-\d{2}$/.test(x.date))
        if(!mapped.length) throw new Error('没有识别到有效打卡行。请使用本软件导出的表头格式。')
        if(!confirm(`识别到 ${mapped.length} 条打卡记录，按日期合并导入？`)) return
        for(const x of mapped){const old=await db.attendance.where('date').equals(x.date).first();await db.attendance.put({...x,...(old?.id?{id:old.id}:{})})}
        alert(`成功导入 ${mapped.length} 条打卡记录`)
      }
      await refresh()
    } catch(err) { alert(`导入失败：${err instanceof Error?err.message:'文件无法读取'}`) }
    finally {input.value=''}
  }
  if(file.name.toLowerCase().endsWith('.json')) reader.readAsText(file)
  else reader.readAsBinaryString(file)
}
function changeMonth(delta:number) {
  const d=new Date(selectedMonth.value+'-01T00:00:00');d.setMonth(d.getMonth()+delta)
  selectedMonth.value=`${d.getFullYear()}-${String(d.getMonth()+1).padStart(2,'0')}`
}
function drawChart() {
  if(!chartEl.value)return
  chart?.dispose();chart=echarts.init(chartEl.value)
  const labels=Array.from({length:12},(_,i)=>`${i+1}月`)
  const values=labels.map((_,i)=>yearRecords.value.filter(x=>Number(x.date.slice(5,7))===i+1).reduce((s,x)=>s+x.amount,0))
  chart.setOption({
    backgroundColor:'transparent',
    tooltip:{trigger:'axis'},
    grid:{left:8,right:8,top:20,bottom:24,containLabel:true},
    xAxis:{type:'category',data:labels,axisLine:{lineStyle:{color:'rgba(150,160,190,.25)'}},axisLabel:{color:'#929bb2'}},
    yAxis:{type:'value',axisLabel:{color:'#929bb2'},splitLine:{lineStyle:{color:'rgba(150,160,190,.12)'}}},
    series:[{type:'bar',data:values,barMaxWidth:22,itemStyle:{borderRadius:[7,7,0,0],color:'#8b7cff'},showBackground:true,backgroundStyle:{color:'rgba(139,124,255,.08)',borderRadius:[7,7,0,0]}}]
  })
}
watch([tab,selectedYear],()=>{if(tab.value==='stats')setTimeout(drawChart,80)})
watch(theme,()=>document.documentElement.dataset.theme=theme.value,{immediate:true})
onMounted(async()=>{await refresh();setInterval(()=>now.value=new Date(),1000);window.addEventListener('resize',()=>chart?.resize())})
</script>

<template>
  <div class="app-shell">
    <header class="topbar">
      <div class="brand-mark"><span class="brand-dot"></span><div><b>Daily Clock</b><small>PERSONAL TRACKER</small></div></div>
      <button class="icon-btn" @click="toggleTheme" :aria-label="'切换主题'"><Sun v-if="theme==='dark'"/><Moon v-else/></button>
    </header>

    <main class="main-content">
      <section v-if="tab==='home'" class="page enter">
        <div class="greeting"><div><span class="eyebrow">{{ now.toLocaleDateString('zh-CN',{weekday:'long',month:'long',day:'numeric'}) }}</span><h1>今天，状态如何？</h1></div><div class="live-pill"><i></i> 本地运行</div></div>
        <div class="hero-card">
          <div class="hero-glow"></div><span class="eyebrow">CURRENT TIME</span>
          <div class="clock-time">{{ now.toLocaleTimeString('zh-CN',{hour:'2-digit',minute:'2-digit',hour12:false}) }}</div>
          <div class="clock-date">{{ now.toLocaleDateString('zh-CN',{year:'numeric',month:'long',day:'numeric'}) }}</div>
          <div class="clock-actions">
            <button class="primary-action" :disabled="clockedIn" @click="clockAction('in')"><ArrowDownToLine :size="18"/>{{ clockedIn?'已完成上班':'上班打卡' }}<Check v-if="clockedIn" :size="17"/></button>
            <button class="secondary-action" :disabled="!clockedIn||clockedOut" @click="clockAction('out')"><ArrowUpFromLine :size="18"/>{{ clockedOut?'已完成下班':'下班打卡' }}<Check v-if="clockedOut" :size="17"/></button>
          </div>
          <div class="hero-foot"><span>上班 {{ todayRecord?.clockIn||'--:--' }}</span><span>下班 {{ todayRecord?.clockOut||'--:--' }}</span></div>
        </div>
        <div class="section-heading"><div><span class="eyebrow">OVERVIEW</span><h2>本月概览</h2></div><button class="text-button" @click="tab='stats'">查看统计 <ChevronRight :size="15"/></button></div>
        <div class="stat-grid">
          <div class="stat-card accent"><div class="stat-icon"><Wallet/></div><span>打卡收入</span><strong>{{ money(monthIncome) }}</strong><small>{{ monthDays }} 天有记录</small></div>
          <div class="stat-card"><div class="stat-icon violet"><CalendarDays/></div><span>累计出勤</span><strong>{{ monthDays }}<em>天</em></strong><small>本月打卡天数</small></div>
          <div class="stat-card"><div class="stat-icon green"><Clock3/></div><span>工作时长</span><strong>{{ Math.round(monthHours*10)/10 }}<em>小时</em></strong><small>已记录时长</small></div>
          <div class="stat-card"><div class="stat-icon orange"><ReceiptText/></div><span>待报销</span><strong>{{ money(pendingAmount) }}</strong><small>本月待到账</small></div>
        </div>
        <div class="section-heading"><div><span class="eyebrow">RECENT</span><h2>最近打卡</h2></div><button class="text-button" @click="tab='records'">全部记录 <ChevronRight :size="15"/></button></div>
        <div v-if="sortedRecords.length" class="list-card">
          <div v-for="item in sortedRecords.slice(0,4)" :key="item.id" class="record-row">
            <div class="date-badge"><b>{{ item.date.slice(8) }}</b><small>{{ item.date.slice(5,7) }}月</small></div>
            <div class="record-main"><b>{{ item.clockIn||'未打上班卡' }} — {{ item.clockOut||'未打下班卡' }}</b><small>{{ fmtHours(duration(item.clockIn,item.clockOut)) }}</small></div>
            <strong class="amount">{{ money(item.amount) }}</strong>
          </div>
        </div>
        <div v-else class="empty-card"><CalendarDays/><b>还没有打卡记录</b><span>完成今天的第一次打卡，开启记录</span></div>
      </section>

      <section v-else-if="tab==='records'" class="page enter">
        <div class="page-title"><span class="eyebrow">ATTENDANCE</span><h1>打卡记录</h1><p>管理每日时间与金额</p></div>
        <div class="month-switch"><button class="icon-btn" @click="changeMonth(-1)"><ChevronLeft/></button><b>{{ monthLabel }}</b><button class="icon-btn" @click="changeMonth(1)"><ChevronRight/></button></div>
        <div class="summary-strip"><div><small>本月收入</small><b>{{ money(monthIncome) }}</b></div><div><small>出勤天数</small><b>{{ monthDays }} 天</b></div><div><small>工作时长</small><b>{{ fmtHours(monthHours) }}</b></div></div>
        <button class="wide-primary" @click="openEditRecord()"><Plus :size="18"/> 添加 / 补录打卡</button>
        <div class="record-list">
          <div v-for="item in monthRecords.slice().sort((a,b)=>b.date.localeCompare(a.date))" :key="item.id" class="record-card">
            <div class="record-card-top"><b>{{ item.date }}</b><strong>{{ money(item.amount) }}</strong></div>
            <div class="record-times"><span><small>上班</small>{{ item.clockIn||'--:--' }}</span><span><small>下班</small>{{ item.clockOut||'--:--' }}</span><span><small>时长</small>{{ fmtHours(duration(item.clockIn,item.clockOut)) }}</span></div>
            <div class="row-actions"><button @click="openEditRecord(item)"><Pencil :size="14"/> 编辑</button><button class="danger-text" @click="deleteRecord(item)"><Trash2 :size="14"/> 删除</button></div>
          </div>
          <div v-if="!monthRecords.length" class="empty-card"><CalendarDays/><b>这个月还没有记录</b><span>可以手动补录历史打卡</span></div>
        </div>
      </section>

      <section v-else-if="tab==='expense'" class="page enter">
        <div class="page-title"><span class="eyebrow">REIMBURSEMENT</span><h1>报销管理</h1><p>清晰追踪每一笔报销</p></div>
        <div class="expense-overview"><div><small>本月报销总额</small><strong>{{ money(monthExpenses.reduce((s,x)=>s+x.amount,0)) }}</strong></div><div class="expense-split"><span>待报销 <b>{{ money(pendingAmount) }}</b></span><span>已报销 <b>{{ money(paidAmount) }}</b></span></div></div>
        <button class="wide-primary" @click="openExpense()"><Plus :size="18"/> 添加报销</button>
        <div class="section-heading compact"><h2>报销明细</h2><span class="muted">{{ monthExpenses.length }} 笔</span></div>
        <div class="record-list">
          <div v-for="item in monthExpenses.slice().sort((a,b)=>b.date.localeCompare(a.date))" :key="item.id" class="record-card">
            <div class="record-card-top"><div><b>{{ item.title }}</b><small class="subline">{{ item.date }} · {{ item.category }}</small></div><strong>{{ money(item.amount) }}</strong></div>
            <div class="expense-bottom"><span :class="['status',item.status]">{{ item.status==='paid'?'已报销':'待报销' }}</span><span class="note">{{ item.note }}</span></div>
            <div class="row-actions"><button @click="openExpense(item)"><Pencil :size="14"/> 编辑</button><button class="danger-text" @click="deleteExpense(item)"><Trash2 :size="14"/> 删除</button></div>
          </div>
          <div v-if="!monthExpenses.length" class="empty-card"><ReceiptText/><b>暂无报销记录</b><span>添加第一笔报销记录</span></div>
        </div>
      </section>

      <section v-else-if="tab==='stats'" class="page enter">
        <div class="page-title"><span class="eyebrow">INSIGHTS</span><h1>数据统计</h1><p>从每一天看见自己的积累</p></div>
        <div class="segmented"><button :class="{active:tab==='stats'}" @click="selectedYear=Number(today.slice(0,4))">年度视图</button><button @click="tab='records'">月度明细</button></div>
        <div class="year-switch"><button class="icon-btn" @click="selectedYear--"><ChevronLeft/></button><b>{{ yearLabel }}</b><button class="icon-btn" @click="selectedYear++"><ChevronRight/></button></div>
        <div class="stat-grid">
          <div class="stat-card accent"><span>全年打卡收入</span><strong>{{ money(yearIncome) }}</strong><small>全年累计</small></div>
          <div class="stat-card"><span>全年出勤</span><strong>{{ yearDays }}<em>天</em></strong><small>有打卡记录的日期</small></div>
          <div class="stat-card"><span>全年报销</span><strong>{{ money(yearExpenses.reduce((s,x)=>s+x.amount,0)) }}</strong><small>{{ yearExpenses.length }} 笔记录</small></div>
          <div class="stat-card"><span>已到账报销</span><strong>{{ money(yearExpenses.filter(x=>x.status==='paid').reduce((s,x)=>s+x.amount,0)) }}</strong><small>年度已报销</small></div>
        </div>
        <div class="chart-card"><div class="chart-title"><div><span class="eyebrow">INCOME TREND</span><h2>每月打卡收入</h2></div><span class="chart-unit">CNY / 月</span></div><div ref="chartEl" class="chart"></div></div>
        <div class="section-heading"><h2>月份汇总</h2></div>
        <div class="list-card">
          <div v-for="m in 12" :key="m" class="month-row"><span>{{ m }} 月</span><div class="month-bar"><i :style="{width:Math.min(100,(yearRecords.filter(x=>Number(x.date.slice(5,7))===m).reduce((s,x)=>s+x.amount,0)/(Math.max(1,...Array.from({length:12},(_,i)=>yearRecords.filter(x=>Number(x.date.slice(5,7))===i+1).reduce((s,x)=>s+x.amount,0)))))*100)+'%'}"></i></div><b>{{ money(yearRecords.filter(x=>Number(x.date.slice(5,7))===m).reduce((s,x)=>s+x.amount,0)) }}</b></div>
        </div>
      </section>

      <section v-else class="page enter">
        <div class="page-title"><span class="eyebrow">PREFERENCES</span><h1>设置</h1><p>管理金额、数据和应用外观</p></div>
        <div class="settings-card">
          <div class="setting-item"><div class="setting-icon"><Wallet/></div><div class="setting-copy"><b>默认每日打卡金额</b><small>新建打卡记录时自动填入</small></div><div class="amount-input"><span>¥</span><input v-model.number="defaultAmount" type="number" min="0" @change="saveDefault"/></div></div>
          <button class="setting-item setting-button" @click="toggleTheme"><div class="setting-icon"><Sun/></div><div class="setting-copy"><b>外观主题</b><small>{{ theme==='dark'?'深色模式':'浅色模式' }}</small></div><span class="setting-value">{{ theme==='dark'?'切换浅色':'切换深色' }}</span></button>
          <div class="setting-item"><div class="setting-icon"><Download/></div><div class="setting-copy"><b>导出本月 Excel</b><small>包含打卡与报销两个工作表</small></div><button class="small-action" @click="exportWorkbook">导出</button></div>
          <button class="setting-item setting-button" @click="exportAllJSON"><div class="setting-icon"><Database/></div><div class="setting-copy"><b>完整数据备份</b><small>导出 JSON，可用于迁移和恢复</small></div><ArrowDownToLine class="setting-arrow"/></button>
          <label class="setting-item import-label"><div class="setting-icon"><Upload/></div><div class="setting-copy"><b>导入数据</b><small>支持 JSON、Excel、CSV 文件</small></div><span class="setting-value">选择文件</span><input type="file" accept=".json,.xlsx,.xls,.csv" @change="importFile" hidden/></label>
        </div>
        <div class="privacy-note"><Database/><div><b>数据仅保存在本机</b><p>Daily Clock 不会将你的考勤、金额或报销信息上传到服务器。请定期导出备份，避免卸载应用或清除应用数据造成丢失。</p></div></div>
        <div class="version">DAILY CLOCK · VERSION 1.0.0</div>
      </section>
    </main>

    <nav class="bottom-nav">
      <button :class="{active:tab==='home'}" @click="tab='home'"><House/><span>首页</span></button>
      <button :class="{active:tab==='records'}" @click="tab='records'"><CalendarDays/><span>打卡</span></button>
      <button :class="{active:tab==='expense'}" @click="tab='expense'"><ReceiptText/><span>报销</span></button>
      <button :class="{active:tab==='stats'}" @click="tab='stats';setTimeout(drawChart,80)"><ChartNoAxesCombined/><span>统计</span></button>
      <button :class="{active:tab==='settings'}" @click="tab='settings'"><Settings/><span>设置</span></button>
    </nav>

    <div v-if="showRecordDialog" class="modal-backdrop" @click.self="showRecordDialog=false">
      <form class="modal-card" @submit.prevent="saveRecord"><div class="modal-head"><div><span class="eyebrow">ATTENDANCE ENTRY</span><h2>{{ editAttendance?'编辑打卡':'添加 / 补录打卡' }}</h2></div><button type="button" class="icon-btn" @click="showRecordDialog=false">×</button></div>
        <label>日期<input v-model="recordForm.date" type="date" required/></label><div class="form-grid"><label>上班时间<input v-model="recordForm.clockIn" type="time"/></label><label>下班时间<input v-model="recordForm.clockOut" type="time"/></label></div><label>打卡金额（元）<input v-model.number="recordForm.amount" type="number" min="0" step="0.01" required/></label><label>备注<textarea v-model="recordForm.note" rows="2" placeholder="可填写备注"></textarea></label><button class="wide-primary" type="submit">保存记录</button>
      </form>
    </div>
    <div v-if="showExpenseDialog" class="modal-backdrop" @click.self="showExpenseDialog=false">
      <form class="modal-card" @submit.prevent="saveExpense"><div class="modal-head"><div><span class="eyebrow">EXPENSE ENTRY</span><h2>{{ editExpense?'编辑报销':'添加报销' }}</h2></div><button type="button" class="icon-btn" @click="showExpenseDialog=false">×</button></div>
        <label>报销日期<input v-model="expenseForm.date" type="date" required/></label><label>报销项目<input v-model="expenseForm.title" placeholder="例如：交通费、餐费" required/></label><div class="form-grid"><label>分类<select v-model="expenseForm.category"><option>交通</option><option>餐饮</option><option>住宿</option><option>办公</option><option>其他</option></select></label><label>金额（元）<input v-model.number="expenseForm.amount" type="number" min="0" step="0.01" required/></label></div><label>报销状态<select v-model="expenseForm.status"><option value="pending">待报销</option><option value="paid">已报销</option></select></label><label>备注<textarea v-model="expenseForm.note" rows="2"></textarea></label><button class="wide-primary" type="submit">保存报销</button>
      </form>
    </div>
  </div>
</template>
