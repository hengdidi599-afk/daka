import Dexie, { type Table } from 'dexie'

export interface Attendance {
  id?: number
  date: string
  clockIn?: string
  clockOut?: string
  amount: number
  note?: string
  createdAt: string
}
export interface Reimbursement {
  id?: number
  date: string
  title: string
  category: string
  amount: number
  status: 'pending' | 'paid'
  note?: string
  createdAt: string
}
export interface Setting {
  key: string
  value: unknown
}
class DailyClockDB extends Dexie {
  attendance!: Table<Attendance, number>
  reimbursements!: Table<Reimbursement, number>
  settings!: Table<Setting, string>
  constructor() {
    super('DailyClockDB')
    this.version(1).stores({
      attendance: '++id, date, createdAt',
      reimbursements: '++id, date, status, category',
      settings: 'key'
    })
  }
}
export const db = new DailyClockDB()
export const todayKey = () => {
  const d = new Date()
  return `${d.getFullYear()}-${String(d.getMonth()+1).padStart(2,'0')}-${String(d.getDate()).padStart(2,'0')}`
}
export const money = (n: number) => new Intl.NumberFormat('zh-CN', { style: 'currency', currency: 'CNY' }).format(n || 0)
export const dateLabel = (s: string) => s ? s.replaceAll('-', '.') : ''
