import type { CapacitorConfig } from '@capacitor/cli'
const config: CapacitorConfig = {
  appId: 'com.dailyclock.app',
  appName: 'Daily Clock',
  webDir: 'dist',
  server: { androidScheme: 'https' }
}
export default config
