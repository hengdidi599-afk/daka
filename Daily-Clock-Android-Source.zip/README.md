# Daily Clock

个人离线打卡、收入与报销管理 Android 应用。前端使用 Vue 3 + TypeScript + Vite，Android 容器使用 Capacitor，本地数据使用 IndexedDB（Dexie）。

## 当前功能
- 上下班打卡、历史补录、编辑和删除
- 默认每日金额、每日独立金额
- 报销记录，待报销/已报销状态
- 月度和年度收入、出勤、报销统计
- 年度月收入柱状图
- 导出本月 Excel（打卡、报销两个工作表）
- JSON 完整备份与恢复
- Excel/CSV 打卡数据导入
- 深色/浅色主题
- 手机响应式布局、安全区域适配、页面和弹窗动效
- 无服务器、无账号，数据留存在本机

## 环境要求
- Node.js 20 或更高版本
- Android Studio（包含 Android SDK）
- JDK 17（以当前 Capacitor/Android Gradle 插件要求为准）

## 本地运行
```bash
npm install
npm run dev
```

## 构建 Android APK
首次初始化 Android 工程：
```bash
npm run android:add
```
构建并同步 Web 资源：
```bash
npm run android:sync
```
打开 Android Studio：
```bash
npm run android:open
```
在 Android Studio 中等待 Gradle Sync 完成，选择 Build > Build Bundle(s) / APK(s) > Build APK(s)。

Debug APK 通常位于：
`android/app/build/outputs/apk/debug/app-debug.apk`

## 重要说明
1. 当前交付的是完整前端源码工程，尚未在此环境中编译出 APK。APK 需要在安装 Android SDK/JDK 的电脑上完成 Gradle 构建。
2. 数据默认只存储在应用本机。卸载应用或清除应用数据会导致本机数据被删除，请定期导出 JSON 备份。
3. Excel/CSV 导入当前按本软件导出的列名识别打卡数据；JSON 用于完整备份恢复。建议先导出备份再执行导入。
4. 通过系统文件选择器选择文件；不同 Android 版本的文件访问体验可能略有差异。
5. 为保证真正离线，应用核心逻辑不依赖网络；CSS 中的字体会回退到系统字体，发布前可将字体资源本地化。
6. 本版本为可运行的初始版本。建议后续补充自动化测试、导入预览/字段映射、数据库迁移测试、应用图标与签名配置，再发布正式 APK。
